
# info about the e-voting system
  FUOYE E-Voting has been at the forefront of transforming the way elections are conducted within our university.
This E-Voting platform is dedicated to providing a reliable and user-friendly digital solution for democratic decision-making.